from langchain_community.document_loaders import PyPDFLoader, DirectoryLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
import os
import sys
from dotenv import load_dotenv


load_dotenv()


HF_TOKEN = os.getenv("HF_token")
if HF_TOKEN:
    os.environ["HUGGINGFACEHUB_API_TOKEN"] = HF_TOKEN
    print("HuggingFace API token loaded successfully from .env file")
else:
    print("WARNING: HuggingFace API token not found in .env file")
DATA_PATH = "data/"

def load_pdf_files(data):
    loader = DirectoryLoader(data, glob="**/*.pdf", loader_cls=PyPDFLoader)
    documents = loader.load()
    return documents

documents = load_pdf_files(data=DATA_PATH)

def create_chunks(extracted_data):
    text_spiltter=RecursiveCharacterTextSplitter(chunk_size=500,chunk_overlap=50)
    text_chunks = text_spiltter.split_documents(extracted_data)
    return text_chunks
text_chunks = create_chunks(extracted_data=documents)


def get_embbeding_model():
    embedding_model= HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    return embedding_model

embedding_model = get_embbeding_model()


DB_FAISS_PATH="vectorstoree/db_faiss"
db= FAISS.from_documents(text_chunks, embedding_model)

db.save_local(DB_FAISS_PATH)



