import streamlit as st
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.chains import RetrievalQA
from  langchain_community.vectorstores import FAISS
from langchain_core.prompts import PromptTemplate
from langchain_huggingface import HuggingFaceEndpoint
from dotenv import load_dotenv
import os
import re


load_dotenv()


HF_TOKEN = os.environ.get("HF_TOKEN")

DB_FAISS_PATH = "vectorstoree/db_faiss"
@st.cache_resource


def load_vector_store():
    embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    try:
        db = FAISS.load_local(
            DB_FAISS_PATH, 
            embedding_model,
            allow_dangerous_deserialization=True
        )
        print("Vector store loaded successfully")
        return db
    except Exception as e:
        print(f"Error loading vector store: {e}")
        return None
    
def set_custom_prompt(template):
    return PromptTemplate(
        input_variables=["context", "question"],
        template=template
    )

def load_llm(repo_id, HF_TOKEN):
    return HuggingFaceEndpoint(
        repo_id=repo_id,
        task="text2text-generation",
        temperature=0.5,
        max_new_tokens=512,
        huggingfacehub_api_token=HF_TOKEN
    )

def main():
    st.title("Streamlit App")

    
    if 'messages' not in st.session_state:
        st.session_state.messages = []

    
    for message in st.session_state.messages:
        with st.chat_message(message['role']):
            st.markdown(message['content'])

   
    prompt = st.chat_input("Enter your question:")
    if prompt:
        
        with st.chat_message("user"):
            st.markdown(prompt)

       
        st.session_state.messages.append({'role': 'user', 'content': prompt})

       
        custom_prompt_template = """
            You are an expert question answering system. Strictly follow these rules:
            1. Answer ONLY based on the provided context
            2. If the answer is not in the context, say "I don't have that information"
            3. Never mention the context itself in your answer
            4. Be direct and concise

            Context: {context}
            Question: {question}

            Answer:
            """
        hugging_face_repo_id = "HuggingFaceH4/zephyr-7b-beta"
        HF_TOKEN = os.environ.get("HF_TOKEN")
        

        try:
            vectorstore= load_vector_store()
            if vectorstore is None:
                raise ValueError("Failed to load vector store")
            retrieval_qa_chain = RetrievalQA.from_chain_type(
                llm = load_llm(repo_id=hugging_face_repo_id, HF_TOKEN=HF_TOKEN),
                chain_type="stuff",
                retriever=vectorstore.as_retriever(search_type="similarity", search_kwargs={"k": 1}),
                return_source_documents=True,
                input_key="query",
                chain_type_kwargs={
                    "prompt": set_custom_prompt(custom_prompt_template),
                    "document_variable_name": "context"
             }
    )
            response = retrieval_qa_chain.invoke({"query": prompt})
            answer = response['result']
            source_docs = response['source_documents']
            result_show=answer+("\n\n source code \n\n:")+str(source_docs)

            
            with st.chat_message("assistant"):
                st.markdown(result_show)

            
            st.session_state.messages.append({'role': 'assistant', 'content': result_show})


        except Exception as e:
            st.error(f"An error occurred: {e}")
            print(f"Error: {e}")

if __name__ == "__main__":
    main()
