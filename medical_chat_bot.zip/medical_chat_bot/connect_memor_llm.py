import os
from langchain_huggingface import HuggingFaceEndpoint
from langchain_core.prompts import PromptTemplate
from langchain.chains import RetrievalQA
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from dotenv import load_dotenv
import re

load_dotenv()


HF_TOKEN = os.environ.get("HF_TOKEN")
if not HF_TOKEN:
    print("HF_TOKEN environment variable is not set.")
    exit(1)

hugging_face_repo_id = "HuggingFaceH4/zephyr-7b-beta"


def load_llm(repo_id):
    return HuggingFaceEndpoint(
        repo_id=repo_id,
        task="text-generation",   # ✅ FIXED
        temperature=0.5,
        max_new_tokens=512,
        huggingfacehub_api_token=HF_TOKEN
    )

custom_prompt_template = """
You are an expert question answering system. Strictly follow these rules:
Answer ONLY based on the provided context.Do NOT repeat the same sentence in multiple ways.
If the answer is not in the context, say: "I don't have that information.Give only ONE clear, concise answer.


Context: {context}
Question: {question}

Answer:
"""

def set_custom_prompt(template):
    return PromptTemplate(
        input_variables=["context", "question"],
        template=template
    )

DB_FAISS_PATH = "vectorstoree/db_faiss"
embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

try:
    db = FAISS.load_local(
        DB_FAISS_PATH, 
        embedding_model,
        allow_dangerous_deserialization=True
    )
    print("Vector store loaded successfully")
except Exception as e:
    print(f"Error loading vector store: {e}")
    exit(1)

retrieval_qa_chain = RetrievalQA.from_chain_type(
    llm=load_llm(hugging_face_repo_id),
    chain_type="stuff",
    retriever=db.as_retriever(search_type="similarity", search_kwargs={"k": 1}),
    return_source_documents=True,
    input_key="query",
    chain_type_kwargs={
        "prompt": set_custom_prompt(custom_prompt_template),
        "document_variable_name": "context"
    }
)


def is_answer_in_context(response, threshold=0.7):
    """
    Check if the answer is actually based on context
    by comparing n-gram overlap between answer and context
    """
    answer = response['result'].lower()
    context = " ".join([doc.page_content for doc in response['source_documents']]).lower()
    
   
    answer_words = set(answer.split())
    context_words = set(context.split())
    overlap = answer_words & context_words
    
   
    similarity = len(overlap) / len(answer_words) if answer_words else 0
    
    return similarity > threshold


user_query = input("Write Any Query here: ")

try:
    response = retrieval_qa_chain.invoke({"query": user_query})
    answer = response['result']
    
    
    if "I don't know" in answer or "don't have information" in answer:
        answer = "I don't have that information in my knowledge base."
    
    print("\nResponse:", answer)
    
    
    if response['source_documents'] and is_answer_in_context(response):
        print("\nSources supporting this answer:")
        for i, doc in enumerate(response['source_documents']):
            
            source_file = os.path.basename(doc.metadata.get('source', 'Unknown'))
            
            print(f"\nSource {i+1}: {source_file}")
            print(f"Page: {doc.metadata.get('page', 'N/A')}")
            
           
            content = doc.page_content
            query_words = user_query.split()
            
            
            start_idx = 0
            for word in query_words:
                idx = content.lower().find(word.lower())
                if idx > -1:
                    start_idx = max(0, idx - 20)
                    break
            
            
            print(f"Relevant content: ...{content[start_idx:start_idx+200]}...")
    else:
        
        print("\nNo supporting sources shown because:")
        if not response['source_documents']:
            print("- No documents were retrieved for this query")
        else:
            print("- The retrieved documents didn't actually contain the answer")
        
except Exception as e:
    print(f"\nError processing query: {e}")