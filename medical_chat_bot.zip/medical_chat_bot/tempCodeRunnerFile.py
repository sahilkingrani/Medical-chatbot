from langchain_communty.document_loaders import PyPDFLoader,DirectoryLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
DATA_PATH = "data/"

def load_pdf_files(data):
    Loarder=DirectoryLoader(data, glob="**/*.pdf", 
                            loader_cls=PyPDFLoader)
    documents=Loarder.load()
    return documents

documents = load_pdf_files(data=DATA_PATH)
print(f"Loaded {len(documents)} documents from {DATA_PATH}")